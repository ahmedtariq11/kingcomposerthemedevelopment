=== ga  Responsive Slider ===
Contributors: Ahmed ALI Tariq
Donate link: http://donate.codingbank.com
Tags: Responsive Slider, ga Responsive Slider, WordPress Responsive Slider, WordPress Slider, WordPress slider plugin.
Requires at least: 3.0.1
Tested up to: 5
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
ga Full Complete Responsive Slider, just go to sliders post, and add new slider. and use this shortcode [ga_sliders] in any pages or posts. then enjoy it.


**Documentations: shortcode is [ga_sliders].

** if you want to use in any template just use this code print <?php echo do_shortcode('[ga_sliders]'); ?>





**Default view latest 5 post.

**Show Manually Post Count of 3 post (just add count="3"). full code ga_sliders [ga_sliders count="3"] with third bracket.






**ga slider image default size 1170px-300px



example:

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

**Documentations: shortcode is [ga_sliders].


