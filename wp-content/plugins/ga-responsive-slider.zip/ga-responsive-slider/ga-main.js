jQuery(document).ready(function() {
    jQuery('.pgwSlider').pgwSlider();
});